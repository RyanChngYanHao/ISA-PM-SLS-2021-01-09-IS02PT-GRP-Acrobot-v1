# OpenAI Gym: Acrobot-v1 (Torque1 Agent)

from acrobot_base_agent import AcrobotBaseAgent

class AcrobotV1Agent(AcrobotBaseAgent):
    def __init__(self):
        super(AcrobotV1Agent, self).__init__()
        self.name = 'AcrobotV1Agent'
    
    def choose_action(self):
        v1 = self.env.state[2]
        if v1 > 0:
            action = 0
        elif v1 < 0:
            action = 2
        else:
            action = 1
        return action

if __name__ == "__main__":    
    base = AcrobotV1Agent()
    base.run_episodes()

    