# OpenAI Gym: Acrobot-v1 (SARSA Agent)

import time
import numpy as np
import math
from acrobot_base_agent import AcrobotBaseAgent
   
class AcrobotSarsaAgent(AcrobotBaseAgent):
    def __init__(self, buckets=(1,1,1,1,2,5), min_lr=0.05, min_epsilon=0, discount=0.99, decay=5):
        super(AcrobotSarsaAgent, self).__init__()
        self.name = 'AcrobotSarsaAgent'
        self.episodes = 1000
        
        self.buckets = buckets
        self.min_lr = min_lr
        self.min_epsilon = min_epsilon
        self.discount = discount
        self.decay = decay
        self.upper_bounds = self.env.observation_space.high
        self.lower_bounds = self.env.observation_space.low

        self.q_table = np.zeros(self.buckets + (self.env.action_space.n,))
    
    def discretize_state(self, obs):
        discretized = []
        for i in range(len(obs)):
            scaling = (obs[i] - self.lower_bounds[i]) / (self.upper_bounds[i] - self.lower_bounds[i])
            new_obs = int(round((self.buckets[i] - 1) * scaling)) # will be between 0 to n-1 buckets
            new_obs = min(self.buckets[i] - 1, max(0, new_obs))
            discretized.append(new_obs)
        return tuple(discretized)
    
    def get_epsilon(self, t):
        return max(self.min_epsilon, min(1., 1. - math.log10((t + 1) / self.decay)))
    
    def get_learning_rate(self, t):
        return max(self.min_lr, min(1., 1. - math.log10((t + 1) / self.decay)))  
    
    def update_table(self, state, action, reward, new_state, new_action):        
        self.q_table[state][action] += self.learning_rate * (
                reward + self.discount * self.q_table[new_state][new_action] - self.q_table[state][action])
        
    def choose_action(self,state):
        if (np.random.random() < self.epsilon):
            return self.env.action_space.sample()
        else:
            return np.argmax(self.q_table[state]) 

    def run_episodes(self):
        print(f'\n<<Acrobot-v1 {self.name} started>>') 
        start = time.process_time() 
        cr_list = []; fs_list = []        
        for episode in range(self.episodes):
            current_state = self.discretize_state(self.env.reset())
            num_episode = episode + 1
            if num_episode < self.episodes - self.track:
                print(f'Training: Episode {num_episode}')
                self.learning_rate = self.get_learning_rate(episode) 
                self.epsilon = self.get_epsilon(episode)
            else:
                print(f'Testing: Episode {num_episode}')
                self.epsilon = 0
            if num_episode == self.episodes:
                print('\nPlaying last episode...')
            ## cumulative reward at the episode
            cr = 0; fs = -self.swings; frames = []
            for i in range(self.swings):
                action = self.choose_action(current_state)        
                obs, reward, terminal, info = self.env.step(action)                
                cr += reward                                
                new_state = self.discretize_state(obs)
                new_action = self.choose_action(new_state) 
                self.update_table(current_state, action, reward, new_state, new_action)
                current_state = new_state 
                if fs == -self.swings and terminal:
                    fs = cr + 1      ## overcount -1 Q terminal == True                           
                self.env.step(action)        
                ## record last episode into frames
                if num_episode == self.episodes:          
                    frame = self.env.render(mode='rgb_array')                    
                    frames.append(self.label_episode(frame, num_episode = num_episode))
            cr_list.append(cr); fs_list.append(fs)
        # plot & gif
        self.env.close()               
        self.save_results(cr_list, fs_list)
        self.render_gif(frames)
        # save time taken
        time_taken = time.process_time() - start
        text_name = f'{self.name}_time_log.txt'
        textfile = open(f'{text_name}', 'a')
        textfile.write(f'{self.name} \n\tTime taken: {time_taken}')
        textfile.close()
        print(f'\n{text_name} saved')
        print(f'\n<<Acrobot-v1 {self.name} ended, time taken = {time_taken}>>')

if __name__ == "__main__":    
    base = AcrobotSarsaAgent() 
    base.run_episodes()

