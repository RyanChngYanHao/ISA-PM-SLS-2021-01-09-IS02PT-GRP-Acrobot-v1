# OpenAI Gym: Acrobot-v1 (base agent, default = random agent)

import gym
import numpy as np
import matplotlib.pyplot as plt
import imageio
import time
from PIL import Image, ImageDraw

class AcrobotBaseAgent:
    def __init__(self, name = 'AcrobotBaseAgent', episodes = 100, swings = 250, track = 100):
        # load original environment from OpenAI Gym, define variables
        self.env = gym.make('Acrobot-v1')
        self.name = name
        self.episodes = episodes
        self.swings = swings
        self.track = track
    
    def choose_action(self):
        # define action to be taken
        action = np.random.choice(self.env.action_space.n)
        return action
    
    def plot_graph(self, filename, title, reward_list):
        # used in save results
        fig = plt.figure()
        plt.plot(range(1, self.episodes + 1), reward_list, '-')
        plt.xlabel('Episode')
        plt.ylabel('Cumulative Reward')
        plt.title(title)
        fig.savefig(filename)
        print(f'\n{filename} saved')    
        
    def save_results(self, cr_list, fs_list):
        # save results as files
        filename1 = f'{self.name}_cumulative_reward.pdf'
        track_list1 = cr_list[(self.episodes - self.track):]
        mean1 = sum(track_list1)/len(track_list1)
        title1 = f'Mean of all rewards = {mean1} for last {self.track} episodes'        
        self.plot_graph(filename1, title1, cr_list)
        
        filename2 = f'{self.name}_first_success.pdf'
        track_list2 = fs_list[(self.episodes - self.track):]
        mean2 = sum(track_list2)/len(track_list2)
        title2 = f'Mean of first reward = {mean2} for last {self.track} episodes'
        self.plot_graph(filename2, title2, fs_list)
        
        fs_list_sorted = sorted(fs_list, reverse = True)
        mean3 = sum(fs_list_sorted[:self.track])/self.track
        text_name = f'{self.name}_cumulative_reward.txt'
        textfile = open(f'{text_name}', 'a')
        textfile.write(f'{text_name} on first success:')
        textfile.write(f'\n\tUnsorted: {fs_list}')
        textfile.write(f'\n\tMean of last {self.track} episodes: {mean2}')
        textfile.write(f'\n\tSorted: {fs_list_sorted}')
        textfile.write(f'\n\tMean of best {self.track} episodes: {mean3}')
        textfile.close()
        print(f'\n{text_name} saved') 
    
    def label_episode(self, frame, num_episode):
        # used in render, label episode during render
        im = Image.fromarray(frame)
        drawer = ImageDraw.Draw(im)
        drawer.text((0,100), f'Episode: {num_episode}', fill='grey')
        return im
    
    def render_gif(self, frames):
        # save last episode
        filename = f'{self.name}_last_episode.gif'
        imageio.mimwrite(filename, frames, fps=60)
        print(f'\n{filename} saved')
        
    def run_episodes(self):
        print(f'\n<<Acrobot-v1 {self.name} started>>') 
        start = time.process_time() 
        cr_list = []; fs_list = []
        for episode in range(self.episodes):
            num_episode = episode + 1 
            print(f'Running episode {num_episode}...')
            if num_episode == self.episodes:
                print('\nPlaying last episode...')
            self.env.reset()
            ## cumulative reward at the episode
            cr = 0; fs = -self.swings; frames = []
            for i in range(self.swings):
                action = self.choose_action()        
                obs, reward, terminal, info = self.env.step(action)
                cr += reward
                if fs == -self.swings and terminal:
                    fs = cr                          
                self.env.step(action)        
                ## record last episode into frames
                if num_episode == self.episodes:
                    frame = self.env.render(mode='rgb_array')                    
                    frames.append(self.label_episode(frame, num_episode = num_episode))
            cr_list.append(cr); fs_list.append(fs)
        # plot & gif
        self.env.close()               
        self.save_results(cr_list, fs_list)
        self.render_gif(frames)
        # save time taken
        time_taken = time.process_time() - start
        text_name = f'{self.name}_time_log.txt'
        textfile = open(f'{text_name}', 'a')
        textfile.write(f'{self.name} \n\tTime taken: {time_taken}')
        textfile.close()
        print(f'\n{text_name} saved')
        print(f'\n<<Acrobot-v1 {self.name} ended, time taken = {time_taken}>>')

if __name__ == "__main__":
    base = AcrobotBaseAgent()  
    base.run_episodes()

    