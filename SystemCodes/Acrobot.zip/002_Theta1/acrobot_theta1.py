# OpenAI Gym: Acrobot-v1 (Theta1 Agent)

from acrobot_base_agent import AcrobotBaseAgent

class AcrobotTheta1Agent(AcrobotBaseAgent):
    def __init__(self):
        super(AcrobotTheta1Agent, self).__init__()
        self.name = 'AcrobotTheta1Agent'
    
    def choose_action(self):        
        theta1 = self.env.state[0]
        if theta1 > 0:
            action = 2
        elif theta1 < 0:
            action = 0
        else:
            action = 1
        return action
    
if __name__ == "__main__":    
    base = AcrobotTheta1Agent()
    base.run_episodes()
    